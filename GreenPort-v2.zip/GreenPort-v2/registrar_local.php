<?php
session_start();
// Verificar si el ciudadano ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.html");
    exit();
}

// Conexión a la Base de Datos
$conn = new mysqli("localhost", "root", "cazadorx", "GreenPort");

// Procesar el envío del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_local'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $categoria = $_POST['categoria'];
    $latitud = $_POST['latitud'];
    $longitud = $_POST['longitud'];
    $direccion = $_POST['direccion'];
    $horario = $_POST['horario'];
    $telefono = $_POST['telefono'];
    $redes = $_POST['redes'];

    // Manejo de la imagen cargada
    $foto = "default_local.png";
    if (isset($_FILES['foto']['name']) && $_FILES['foto']['name'] != "") {
        $foto = time() . "_" . $_FILES['foto']['name'];
        if (!file_exists("Assets/img/locales")) {
            mkdir("Assets/img/locales", 0777, true);
        }
        move_uploaded_file($_FILES['foto']['tmp_name'], "Assets/img/locales/" . $foto);
    }

    // Inserción en la base de datos (Queda en 'pendiente' para filtro del admin)
    $stmt = $conn->prepare("INSERT INTO locales_comunitarios (usuario_id, nombre, descripcion, categoria, latitud, longitud, direccion, horario, telefono, redes_sociales, foto_url, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente')");
    $stmt->bind_param("isssddsssss", $usuario_id, $nombre, $descripcion, $categoria, $latitud, $longitud, $direccion, $horario, $telefono, $redes, $foto);
    
    if ($stmt->execute()) {
        echo "<script>
            alert('¡Propuesta registrada con éxito! Aparecerá en el mapa en cuanto el administrador la valide.');
            window.location.href = 'service.php';
        </script>";
    } else {
        echo "<script>alert('Error al registrar el lugar. Inténtalo de nuevo.');</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>GreenPort - Registrar Local</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="Assets/img/logo.png" rel="icon" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="Assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        body { background-color: #f8f9fa; font-family: 'Poppins', sans-serif; }
        .form-container { background: #ffffff; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        #mapa-registro { height: 300px; width: 100%; border-radius: 10px; border: 2px solid #e9ecef; }
    </style>
</head>
<body>

    <div class="container-fluid bg-light py-2 px-5 border-bottom">
        <div class="d-flex justify-content-between align-items-center">
            <a href="principal_ciudadano.php" class="text-decoration-none">
                <h3 class="m-0 text-primary"><span class="text-dark">GREEN</span>PORT</h3>
            </a>
            <span class="text-muted small">Panel Ciudadano &gt; Registrar Local</span>
        </div>
    </div>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-9 col-md-11">
                <div class="form-container p-5">
                    <div class="d-flex align-items-center mb-4">
                        <i class="fas fa-map-marked-alt fa-2x text-info mr-3"></i>
                        <div>
                            <h2 class="font-weight-bold m-0" style="color: #333;">Registrar Sitio Comunitario</h2>
                            <p class="text-muted m-0 small">Añade un comercio o rincón local para promoverlo en el mapa turístico de Acapulco.</p>
                        </div>
                    </div>
                    <hr class="mb-4">

                    <form action="registrar_local.php" method="POST" enctype="multipart/form-data">
                        
                        <div class="row">
                            <div class="form-group col-md-7">
                                <label class="font-weight-bold text-dark">Nombre del Establecimiento / Lugar</label>
                                <input type="text" name="nombre" class="form-control" required placeholder="Ej: Mariscos Pipo">
                            </div>
                            <div class="form-group col-md-5">
                                <label class="font-weight-bold text-dark">Categoría</label>
                                <select name="categoria" class="form-control" required>
                                    <option value="Restaurantes">Restaurantes</option>
                                    <option value="Cafeterías">Cafeterías</option>
                                    <option value="Artesanías">Artesanías</option>
                                    <option value="Playas">Playas</option>
                                    <option value="Turismo">Turismo</option>
                                    <option value="Hospedaje local">Hospedaje local</option>
                                    <option value="Eventos">Eventos</option>
                                    <option value="Cultura">Cultura</option>
                                    <option value="Vida nocturna">Vida nocturna</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="font-weight-bold text-dark">Descripción de Atractivos</label>
                            <textarea name="descripcion" class="form-control" rows="3" required placeholder="Describe qué comida ofrecen, especialidades, artesanías o recomendaciones para los visitantes..."></textarea>
                        </div>

                        <div class="form-group">
                            <label class="font-weight-bold text-info"><i class="fas fa-crosshairs mr-1"></i> Ubicación exacta (Haz clic sobre el mapa):</label>
                            <div id="mapa-registro" class="mb-2"></div>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" id="lat" name="latitud" class="form-control" placeholder="Latitud" readonly required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" id="lon" name="longitud" class="form-control" placeholder="Longitud" readonly required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="font-weight-bold text-dark">Dirección Física</label>
                            <input type="text" name="direccion" class="form-control" required placeholder="Calle, Número, Colonia o Zona de Playa">
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4">
                                <label class="font-weight-bold text-dark">Horario de Atención</label>
                                <input type="text" name="horario" class="form-control" placeholder="Ej: Jueves a Dom 11am - 7pm">
                            </div>
                            <div class="form-group col-md-4">
                                <label class="font-weight-bold text-dark">Teléfono de Contacto</label>
                                <input type="text" name="telefono" class="form-control" placeholder="Ej: 7444123456">
                            </div>
                            <div class="form-group col-md-4">
                                <label class="font-weight-bold text-dark">Redes Sociales (Enlace)</label>
                                <input type="text" name="redes" class="form-control" placeholder="Link de Facebook/Instagram">
                            </div>
                        </div>

                        <div class="form-group mb-4">
                            <label class="font-weight-bold text-dark">Fotografía Informativa del Lugar</label>
                            <input type="file" name="foto" class="form-control-file">
                        </div>

                        <hr class="mb-4">
                        <div class="text-right">
                            <a href="principal_ciudadano.php" class="btn btn-secondary px-4 font-weight-bold mr-2" style="border-radius: 5px;">Cancelar</a>
                            <button type="submit" name="guardar_local" class="btn btn-info px-5 font-weight-bold text-white" style="border-radius: 5px; background-color: #17a2b8;">Guardar y Enviar Propuesta</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        // Inicializar el mapa de registro en Acapulco
        var mapa = L.map('mapa-registro').setView([16.8531, -99.8749], 13);
        
        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap &copy; CARTO'
        }).addTo(mapa);

        var marcador;

        // Evento de clic para capturar latitud y longitud automáticamente
        mapa.on('click', function(e) {
            var latitud = e.latlng.lat;
            var longitud = e.latlng.lng;

            document.getElementById('lat').value = latitud.toFixed(6);
            document.getElementById('lon').value = longitud.toFixed(6);

            if (marcador) {
                marcador.setLatLng(e.latlng);
            } else {
                marcador = L.marker(e.latlng).addTo(mapa);
            }
        });
    </script>
</body>
</html>