<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

// Query adaptado a 'prioridad' y 'url_archivo'
$sql = "SELECT r.id, r.titulo, r.descripcion, r.tipo_residuo, r.prioridad, r.latitud, r.longitud, r.fecha_reporte, r.estado, e.url_archivo AS foto 
        FROM reportes r
        LEFT JOIN evidencias e ON r.id = e.reporte_id
        GROUP BY r.id 
        ORDER BY r.fecha_reporte DESC";

$result = $conn->query($sql);
$reportes = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $reportes[] = $row;
    }
}

echo json_encode($reportes);
$conn->close();
?>