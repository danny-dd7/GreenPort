<?php
session_start();
// Conexión a la Base de Datos
$conn = new mysqli("localhost", "root", "cazadorx", "GreenPort");

// Procesar el envío de un nuevo local mediante el Modal
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registrar_local'])) {
    if (!isset($_SESSION['usuario_id'])) {
        echo "<script>alert('Debes iniciar sesión para proponer un negocio.');</script>";
    } else {
        $usuario_id = $_SESSION['1'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $categoria = $_POST['categoria'];
        $latitud = $_POST['latitud'];
        $longitud = $_POST['longitud'];
        $direccion = $_POST['direccion'];
        $horario = $_POST['horario'];
        $telefono = $_POST['telefono'];
        $redes = $_POST['redes'];

        // Manejo básico de la fotografía
        $foto = "default_local.png";
        if (isset($_FILES['foto']['name']) && $_FILES['foto']['name'] != "") {
            $foto = time() . "_" . $_FILES['foto']['name'];
            
            // Crear carpeta si no existe
            if (!file_exists("Assets/img/locales")) {
                mkdir("Assets/img/locales", 0777, true);
            }
            move_uploaded_file($_FILES['foto']['tmp_name'], "Assets/img/locales/" . $foto);
        }

        $stmt = $conn->prepare("INSERT INTO locales_comunitarios (usuario_id, nombre, descripcion, categoria, latitud, longitud, direccion, horario, telefono, redes_sociales, foto_url, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendiente')");
        $stmt->bind_param("isssddsssss", $usuario_id, $nombre, $descripcion, $categoria, $latitud, $longitud, $direccion, $horario, $telefono, $redes, $foto);
        
        if ($stmt->execute()) {
            echo "<script>alert('¡Propuesta enviada con éxito! Pasará a revisión para evitar grandes cadenas.'); window.location.href='service.php';</script>";
        }
        $stmt->close();
    }
}

// Obtener todos los locales APROBADOS por el administrador para pintarlos en el mapa
$pines_locales = [];
$res = $conn->query("SELECT * FROM locales_comunitarios WHERE estado = 'aprobado'");
while ($row = $res->fetch_assoc()) {
    $pines_locales[] = $row;
}
$pines_json = json_encode($pines_locales);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>GreenPort - Servicios</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="GreenPort, servicios ambientales, reportes ciudadanos, Acapulco" name="keywords">
    <meta content="GreenPort es una plataforma para reportes ciudadanos de residuos urbanos y costeros." name="description">

    <link href="Assets/img/logo.png" rel="icon" type="image/png">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <link href="Assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="Assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <link href="Assets/css/style.css" rel="stylesheet">

    <style>
        #mapa-comunitario { height: 550px; width: 100%; border-radius: 15px; box-shadow: 0 8px 24px rgba(0,0,0,0.12); z-index: 1; }
        .filtro-btn { transition: 0.3s; font-weight: 500; }
        .filtro-btn:hover, .filtro-btn.active { background-color: #7AB730 !important; color: white !important; border-color: #7AB730 !important; }
        .popup-local-img { width: 100%; height: 110px; object-fit: cover; border-radius: 8px; margin-bottom: 8px; }
    </style>
</head>

<body>

    <div class="container-fluid bg-light pt-3 d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                    <div class="d-inline-flex align-items-center">
                        <p><i class="fa fa-envelope mr-2"></i>greenportmxt@gmail.com</p>
                        <p class="text-body px-3">|</p>
                        <p><i class="fa fa-phone-alt mr-2"></i>+52 744 107 4403</p>
                    </div>
                </div>

                <div class="col-lg-6 text-center text-lg-right">
                    <div class="d-inline-flex align-items-center">
                        <a class="text-primary px-3" href="https://www.facebook.com/profile.php?id=61589116211500">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a class="text-primary px-3" href="https://x.com/GreenportMX">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a class="text-primary px-3" href="https://www.instagram.com/greenportmx?igsh=MzFvOGlxNTl6MGd3">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a class="text-primary pl-3" href="https://youtube.com/@greenportmx?si=ToUSrcrmsFDMjHEH">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative nav-bar p-0">
        <div class="container-lg position-relative p-0 px-lg-3" style="z-index: 9;">
            <nav class="navbar navbar-expand-lg bg-light navbar-light shadow-lg py-3 py-lg-0 pl-3 pl-lg-5">

                <a href="" class="navbar-brand">
                    <h1 class="m-0 text-primary">
                        <span class="text-dark">GREEN</span>PORT
                    </h1>
                </a>

                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
                    <div class="navbar-nav ml-auto py-0">

                        <a href="index.html" class="nav-item nav-link">Inicio</a>
                        <a href="about.html" class="nav-item nav-link">Acerca de</a>
                        <a href="service.php" class="nav-item nav-link active">Servicios</a>

                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Páginas</a>
                            <div class="dropdown-menu border-0 rounded-0 m-0">
                                <a href="single.html" class="dropdown-item">Detalle de Blog</a>
                                <a href="destination.html" class="dropdown-item">Zonas Acapulco</a>
                                <a href="Administrador.html" class="dropdown-item">Administradores</a>
                            </div>
                        </div>

                        <a href="contact.html" class="nav-item nav-link">Contacto</a>

                    </div>
                </div>
            </nav>
        </div>
    </div>
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-4 text-white text-uppercase">Servicios</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase">
                        <a class="text-white" href="index.html">Inicio</a>
                    </p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Servicios</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">MAPA COMUNITARIO</h6>
                <h1>Promoción de Negocios y Lugares Locales</h1>
                <p class="text-muted mx-auto" style="max-width: 700px;">
                    GreenPort facilita el reporte ciudadano de residuos en espacios públicos. Esta página tendrá un mapa interactivo independiente del mapa ambiental para apoyar a la economía local.
                </p>
            </div>

            <div class="row justify-content-center mb-4">
                <div class="col-12 text-center">
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn active" onclick="filtrarMapa('Todos')">Todos</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Restaurantes')"><i class="fa fa-utensils mr-1"></i> Restaurantes</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Cafeterías')"><i class="fa fa-coffee mr-1"></i> Cafeterías</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Playas')"><i class="fa fa-sun mr-1"></i> Playas</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Artesanías')"><i class="fa fa-palette mr-1"></i> Artesanías</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Turismo')"><i class="fa fa-map mr-1"></i> Turismo</button>
                    <button class="btn btn-outline-dark mx-1 my-1 filtro-btn" onclick="filtrarMapa('Cultura')"><i class="fa fa-landmark mr-1"></i> Cultura</button>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-12 text-right">
                    <?php if(isset($_SESSION['usuario_id'])): ?>
                        <button class="btn btn-primary py-2 px-4 font-weight-bold" data-toggle="modal" data-target="#modalRegistrarLocal">
                            <i class="fa fa-plus-circle mr-2"></i>Registrar Lugar o Emprendimiento
                        </button>
                    <?php else: ?>
                        <a href="login.html" class="btn btn-warning py-2 px-4 font-weight-bold">
                            <i class="fa fa-sign-in-alt mr-2"></i>Inicia sesión para registrar un lugar
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div id="mapa-comunitario"></div>
                </div>
            </div>

        </div>
    </div>
    <div class="modal fade" id="modalRegistrarLocal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="service.php" method="POST" enctype="multipart/form-data" class="p-4">
                    <h4 class="font-weight-bold text-primary mb-2"><i class="fa fa-store-alt mr-2"></i>Proponer Sitio o Negocio Local</h4>
                    <p class="text-muted small">Registra tu comercio o rincón favorito de Acapulco. (Las cadenas multinacionales como OXXO o Walmart no son aceptadas).</p>
                    <hr>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="font-weight-bold">Nombre del Lugar</label>
                            <input type="text" name="nombre" class="form-control" required placeholder="Ej: Cafetería El Puerto">
                        </div>
                        <div class="form-group col-md-6">
                            <label class="font-weight-bold">Categoría</label>
                            <select name="categoria" class="form-control" required>
                                <option value="Restaurantes">Restaurantes</option>
                                <option value="Cafeterías">Cafeterías</option>
                                <option value="Artesanías">Artesanías</option>
                                <option value="Playas">Playas</option>
                                <option value="Turismo">Turismo</option>
                                <option value="Hospedaje local">Hospedaje local</option>
                                <option value="Eventos">Eventos</option>
                                <option value="Cultura">Cultura</option>
                                <option value="Vida nocturna">Vida nocturna</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Descripción</label>
                        <textarea name="descripcion" class="form-control" rows="3" required placeholder="Escribe los horarios, especialidades o qué hace especial este rincón..."></textarea>
                    </div>

                    <p class="text-primary small font-weight-bold mb-1">* Haz clic sobre el mapa en la ubicación exacta del lugar para obtener sus coordenadas:</p>
                    <div id="mapa-seleccion" style="height: 220px; border-radius: 8px;" class="mb-3"></div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="small font-weight-bold text-muted">Latitud</label>
                            <input type="text" id="form-lat" name="latitud" class="form-control" readonly required>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="small font-weight-bold text-muted">Longitud</label>
                            <input type="text" id="form-lon" name="longitud" class="form-control" readonly required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Dirección Completa</label>
                        <input type="text" name="direccion" class="form-control" required placeholder="Calle, Número, Colonia o Referencia">
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label class="font-weight-bold">Horario</label>
                            <input type="text" name="horario" class="form-control" placeholder="Ej: Todos los días 8am - 10pm">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="font-weight-bold">Teléfono</label>
                            <input type="text" name="telefono" class="form-control" placeholder="Ej: 7441234567">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="font-weight-bold">Redes Sociales (Link)</label>
                            <input type="text" name="redes" class="form-control" placeholder="Enlace de Facebook o Instagram">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Imagen Comercial / Foto del lugar</label>
                        <input type="file" name="foto" class="form-control-file">
                    </div>

                    <div class="text-right mt-3">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="submit" name="registrar_local" class="btn btn-primary">Enviar Propuesta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<section class="py-5 bg-light border-top">
    <div class="container">
        
        <div class="text-center mb-5">
            <h6 class="text-primary text-uppercase" style="letter-spacing: 2px;">Reseñas de la Comunidad</h6>
            <h2 class="font-weight-bold text-dark" id="titulo-comentarios">Lo que dicen los clientes</h2>
            <p class="text-muted small" id="subtitulo-comentarios">Selecciona un negocio en el mapa para ver sus opiniones y calificarlo.</p>
        </div>

        <div class="row">
            <div class="col-lg-7 mb-4">
                <h5 class="font-weight-bold text-dark mb-4"><i class="fas fa-comments text-success mr-2"></i>Opiniones de usuarios</h5>
                <div id="contenedor-comentarios" style="max-height: 450px; overflow-y: auto; padding-right: 10px;">
                    <div class="alert alert-info text-center shadow-sm" style="border-radius: 10px;">
                        <i class="fas fa-info-circle mr-2 fa-lg"></i> Por favor, haz clic sobre el marcador de cualquier local en el mapa para cargar su caja de comentarios.
                    </div>
                </div>
            </div>

            <div class="col-lg-5" id="bloque-formulario-opinion" style="display: none;">
                <div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 15px;">
                    <h5 class="font-weight-bold text-dark mb-3"><i class="fas fa-star text-warning mr-2"></i>Calificar este lugar</h5>
                    
                    <form id="form-comentario">
                        <input type="hidden" id="input-local-id" name="local_id">
                        
                        <div class="form-group mb-3">
                            <label class="small font-weight-bold text-muted d-block">Tu valoración:</label>
                            <div class="sistema-estrellas" style="font-size: 1.8rem; cursor: pointer;">
                                <i class="far fa-star text-warning estrella-voto" data-valor="1"></i>
                                <i class="far fa-star text-warning estrella-voto" data-valor="2"></i>
                                <i class="far fa-star text-warning estrella-voto" data-valor="3"></i>
                                <i class="far fa-star text-warning estrella-voto" data-valor="4"></i>
                                <i class="far fa-star text-warning estrella-voto" data-valor="5"></i>
                            </div>
                            <input type="hidden" id="input-estrellas" name="estrellas" value="0">
                        </div>

                        <div class="form-group mb-3">
                            <label class="small font-weight-bold text-muted">Escribe tu reseña u opinión:</label>
                            <textarea name="comentario" id="texto-comentario" class="form-control form-control-sm" rows="3" required placeholder="Cuéntale a otros tu experiencia en este sitio..."></textarea>
                        </div>

                        <button type="submit" class="btn btn-success btn-block font-weight-bold py-2 shadow-sm" style="border-radius: 25px; background-color: #7ab434; border:none;">
                            <i class="fas fa-paper-plane mr-2"></i>Publicar Calificación
                        </button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>

    <div class="container-fluid bg-dark text-white-50 py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5">
            <div class="col-lg-3 col-md-6 mb-5">
                <a href="" class="navbar-brand">
                    <h1 class="text-primary">
                        <span class="text-white">GREEN</span>PORT
                    </h1>
                </a>
                <p>GreenPort facilita el reporte ciudadano de residuos en espacios públicos.</p>
            </div>
        </div>
    </div>
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="Assets/lib/easing/easing.min.js"></script>
    <script src="Assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="Assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="Assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="Assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script src="Assets/mail/jqBootstrapValidation.min.js"></script>
    <script src="Assets/mail/contact.js"></script>

    <script src="Assets/js/main.js"></script>

<script>
    // Inicializar el Mapa de Leaflet apuntando a Acapulco
    var mapaTurismo = L.map('mapa-comunitario').setView([16.8531, -99.8749], 13);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO'
    }).addTo(mapaTurismo);

    // Inyección JSON segura de la Base de datos PHP
    var baseLocales = <?php echo $pines_json; ?>;
    var marcadoresActivos = [];

    function renderizarPines(categoriaFiltro) {
        // Eliminar marcadores previos del mapa
        marcadoresActivos.forEach(m => mapaTurismo.removeLayer(m));
        marcadoresActivos = [];

        baseLocales.forEach(function(local) {
            if (categoriaFiltro === 'Todos' || local.categoria === categoriaFiltro) {
                var popupHtml = `
                    <div style="width:230px; font-family:'Poppins', sans-serif;">
                        <img src="Assets/img/locales/${local.foto_url}" class="popup-local-img" onerror="this.src='Assets/img/logo.png'">
                        <h6 style="margin:0 0 3px 0; font-weight:700; color:#7AB730;">${local.nombre}</h6>
                        <span class="badge badge-success mb-2" style="font-size:10px; padding:4px 6px;">${local.categoria}</span>
                        <p style="font-size:12px; margin:0 0 6px 0; color:#555; line-height:1.4;">${local.descripcion}</p>
                        <hr style="margin:6px 0;">
                        <small class="d-block text-dark"><b>📍 Dir:</b> ${local.direccion}</small>
                        <small class="d-block text-dark"><b>🕒 Horario:</b> ${local.horario || 'No especificado'}</small>
                        <small class="d-block text-dark"><b>📞 Tel:</b> ${local.telefono || 'S/N'}</small>
                        ${local.redes_sociales ? `<a href="${local.redes_sociales}" target="_blank" class="btn btn-block btn-sm btn-info text-white mt-2 py-1" style="font-size:11px; font-weight:600;"><i class="fab fa-instagram mr-1"></i> Visitar Enlace</a>` : ''}
                    </div>
                `;
                
                var marcador = L.marker([parseFloat(local.latitud), parseFloat(local.longitud)]).addTo(mapaTurismo)
                    .bindPopup(popupHtml);
                
                // ==========================================
                //  👇 ¡AQUÍ VA EL EVENTO DINÁMICO DE CLIC! 👇
                // ==========================================
                marcador.on('click', function() {
                    // 1. Usamos los datos del objeto 'local' que ya vienen de tu baseLocales
                    var idLocal = local.id; 
                    var nombreLocal = local.nombre;

                    // 2. Cambiar dinámicamente el título y subtítulo de la sección de abajo
                    document.getElementById('titulo-comentarios').innerText = "Lo que dicen los clientes de " + nombreLocal;
                    document.getElementById('subtitulo-comentarios').innerText = "Opiniones reales e independientes de la comunidad de GreenPort.";

                    // 3. Guardar el ID del local en el input oculto y mostrar el formulario para calificar
                    document.getElementById('input-local-id').value = idLocal;
                    document.getElementById('bloque-formulario-opinion').style.display = 'block';

                    // 4. Resetear el formulario (limpiar estrellas del envío anterior)
                    resetearFormularioVoto();

                    // 5. Cargar los comentarios de este local usando AJAX asíncrono
                    cargarComentariosAjax(idLocal);
                });
                
                marcadoresActivos.push(marcador);
            }
        });
    }

    // Carga inicial (Todos los pines)
    renderizarPines('Todos');

    // Control de los filtros de botones superiores
    function filtrarMapa(categoria) {
        $('.filtro-btn').removeClass('active');
        $(window.event.target).addClass('active');
        renderizarPines(categoria);
    }

    // Mini mapa interactivo interno del Modal para capturar Coordenadas (Limpiado y corregido)
    var mapaSeleccion;
    var marcadorSeleccion;
    $('#modalRegistrarLocal').on('shown.bs.modal', function () {
        if (!mapaSeleccion) {
            mapaSeleccion = L.map('mapa-seleccion').setView([16.8531, -99.8749], 12);
            L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png').addTo(mapaSeleccion);

            mapaSeleccion.on('click', function(e) {
                var lat = e.latlng.lat;
                var lon = e.latlng.lng;
                document.getElementById('form-lat').value = lat.toFixed(6);
                document.getElementById('form-lon').value = lon.toFixed(6);

                if (marcadorSeleccion) {
                    marcadorSeleccion.setLatLng(e.latlng);
                } else {
                    marcadorSeleccion = L.marker(e.latlng).addTo(mapaSeleccion);
                }
            });
        }
        mapaSeleccion.invalidateSize();
    });

    // Funciones de control dinámico
    function cargarComentariosAjax(idLocal) {
        var contenedor = document.getElementById('contenedor-comentarios');
        contenedor.innerHTML = '<div class="text-center py-4"><i class="fas fa-spinner fa-spin fa-2x text-muted"></i><p class="small text-muted mt-2">Cargando comentarios...</p></div>';

        fetch('obtener_comentarios.php?local_id=' + idLocal)
            .then(response => response.json())
            .then(data => {
                contenedor.innerHTML = '';
                if (data.length === 0) {
                    contenedor.innerHTML = '<div class="alert alert-light text-center border py-4" style="border-radius:10px;"><p class="m-0 text-muted small">Este local aún no tiene calificaciones. ¡Sé el primero en dejar tu opinión!</p></div>';
                    return;
                }
                data.forEach(resena => {
                    let estrellasHTML = '';
                    
                    // Generar las 5 estrellas usando caracteres Unicode nativos que NUNCA fallan
                    for (let i = 1; i <= 5; i++) {
                        if (i <= resena.estrellas) {
                            // Estrella rellena nativa dorada
                            estrellasHTML += '<span style="color: #ffc107; font-size: 1.2rem; margin-right: 2px;">★</span>';
                        } else {
                            // Estrella vacía nativa gris claro / contorno
                            estrellasHTML += '<span style="color: #e4e6eb; font-size: 1.2rem; margin-right: 2px;">★</span>';
                        }
                    }
                    
                    // Aquí continúas concatenando el HTML en tu contenedor...
                    contenedor.innerHTML += `
                        <div class="card border-0 shadow-sm p-3 mb-3 bg-white" style="border-radius: 12px;">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <strong class="text-dark small"><i class="fas fa-user-circle mr-1"></i> ${resena.usuario_nombre}</strong>
                                <div>${estrellasHTML}</div>
                            </div>
                            <p class="text-muted m-0 small" style="line-height:1.4;">"${resena.comentario}"</p>
                            <small class="text-muted d-block text-right" style="font-size:10px;">${resena.fecha}</small>
                        </div>
                    `;
                });
            });
    }

    // Lógica interactiva para pintar las estrellas al pasar o dar clic
    document.querySelectorAll('.estrella-voto').forEach(estrella => {
        estrella.addEventListener('click', function() {
            let valor = this.getAttribute('data-valor');
            document.getElementById('input-estrellas').value = valor;
            
            document.querySelectorAll('.estrella-voto').forEach(e => {
                if (e.getAttribute('data-valor') <= valor) {
                    e.classList.replace('far', 'fas');
                } else {
                    e.classList.replace('fas', 'far');
                }
            });
        });
    });

    function resetearFormularioVoto() {
        document.getElementById('texto-comentario').value = '';
        document.getElementById('input-estrellas').value = '0';
        document.querySelectorAll('.estrella-voto').forEach(e => e.classList.replace('fas', 'far'));
    }

    // Procesar el envío de la nueva reseña sin recargar pantalla
    document.getElementById('form-comentario').addEventListener('submit', function(e) {
        e.preventDefault();
        let estrellas = document.getElementById('input-estrellas').value;
        if (estrellas == 0) {
            alert('Por favor, selecciona al menos una estrella para calificar.');
            return;
        }

        let formData = new FormData(this);
        fetch('guardar_comentario.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                let idLocal = document.getElementById('input-local-id').value;
                cargarComentariosAjax(idLocal);
                resetearFormularioVoto();
            } else {
                alert(data.error || 'Error al guardar la reseña.');
            }
        });
    });
    
</script>

</body>
</html>