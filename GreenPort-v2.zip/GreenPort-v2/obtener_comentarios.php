<?php
$conn = new mysqli("localhost", "root", "cazadorx", "GreenPort");
$local_id = intval($_GET['local_id'] ?? 0);

$query = "SELECT c.*, u.nombre AS usuario_nombre 
          FROM comentarios_locales c 
          LEFT JOIN usuarios u ON c.usuario_id = u.id 
          WHERE c.local_id = ? 
          ORDER BY c.fecha DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $local_id);
$stmt->execute();
$result = $stmt->get_result();

$comentarios = [];
while($row = $result->fetch_assoc()) {
    $comentarios[] = [
        'usuario_nombre' => htmlspecialchars($row['usuario_nombre'] ?? 'Anónimo'),
        'estrellas' => intval($row['estrellas']),
        'comentario' => htmlspecialchars($row['comentario']),
        'fecha' => date("d/m/Y H:i", strtotime($row['fecha']))
    ];
}
echo json_encode($comentarios);
?>