<?php
// 1. Iniciar la sesión global para recordar al usuario
session_start();

// 2. Conexión a la base de datos de GreenPort (Workbench)
$servername = "localhost";
$username = "root";
$password = "cazadorx"; // Tu contraseña de Workbench activa
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error crítico: No se pudo conectar con la base de datos.");
}

// 3. Procesar datos solo si la petición viene por método POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    // Recoger los datos usando los atributos 'name' del formulario HTML
    $email    = trim($_POST['correo']);
    $password = $_POST['password'];

    // Validación básica de campos vacíos
    if (empty($email) || empty($password)) {
        echo "<script>alert('Por favor, llena todos los campos obligatorios.'); window.history.back();</script>";
        exit;
    }

    // 4. Buscar al usuario en la base de datos por su correo electrónico
    $stmt = $conn->prepare("SELECT id, nombre, apellido, password_hash, rol, activo FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Comprobar si el registro existe
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // 5. Verificar si la cuenta no ha sido dada de baja (inactiva)
        if ((bool)$user['activo'] === false) {
            echo "<script>alert('Esta cuenta se encuentra inactiva. Contacta al administrador.'); window.history.back();</script>";
            exit;
        }

        // 6. Validar la contraseña usando el hash almacenado
        if (password_verify($password, $user['password_hash'])) {
            
            // ¡Credenciales correctas! Guardamos los datos clave en la sesión
            $_SESSION['usuario_id']     = $user['id'];
            $_SESSION['usuario_nombre'] = $user['nombre'] . " " . $user['apellido'];
            $_SESSION['usuario_rol']    = $user['rol'];

            // 7. Redirección inteligente según el rol
            if ($user['rol'] === 'admin' || $user['rol'] === 'operador') {
                header("Location: Panel_Control.php"); // Redirige al panel dinámico
            } else {
                header("Location: principal_ciudadano.php"); // Redirige a la zona de reportes ciudadanos
            }
            exit;

        } else {
            // Contraseña errónea
            echo "<script>alert('La contraseña ingresada es incorrecta.'); window.history.back();</script>";
        }
    } else {
        // Correo no registrado
        echo "<script>alert('El correo electrónico no coincide con ninguna cuenta registrada.'); window.history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>