<?php
// Configuración local del servidor de correo
define('SMTP_USER', 'greenportmxt@gmail.com');
define('SMTP_PASS', 'ryph ostv cdfj ogiz'); // Cada compañero pondrá la suya aquí
?>