<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Debes iniciar sesión para comentar.']);
    exit();
}

$conn = new mysqli("localhost", "root", "cazadorx", "GreenPort");
$usuario_id = $_SESSION['usuario_id'];
$local_id = intval($_POST['local_id'] ?? 0);
$estrellas = intval($_POST['estrellas'] ?? 0);
$comentario = trim($_POST['comentario'] ?? '');

if($local_id > 0 && $estrellas >= 1 && $estrellas <= 5 && !empty($comentario)) {
    $stmt = $conn->prepare("INSERT INTO comentarios_locales (local_id, usuario_id, estrellas, comentario) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $local_id, $usuario_id, $estrellas, $comentario);
    if($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error interno de base de datos.']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Datos incompletos o inválidos.']);
}
?>