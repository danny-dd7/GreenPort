// Coordenadas iniciales: Centro de Acapulco de Juárez
const acapulcoCoords = [16.8531, -99.8237];
const map = L.map('map').setView(acapulcoCoords, 13);

//mapa 
L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    attribution: '© OpenStreetMap contributors © CARTO',
    subdomains: 'abcd',
    maxZoom: 20
}).addTo(map);

// Variable global para el marcador que se creará al reportar
let marcadorReporte = null;

// 1. EVENTO: Hacer clic en el mapa para seleccionar ubicación
map.on('click', function(e) {
    const lat = e.latlng.lat;
    const lng = e.latlng.lng;

    // Colocar las coordenadas en los inputs bloqueados
    document.getElementById('latitud').value = lat.toFixed(6);
    document.getElementById('longitud').value = lng.toFixed(6);

    // Mover o crear el marcador de selección
    if (marcadorReporte) {
        marcadorReporte.setLatLng(e.latlng);
    } else {
        marcadorReporte = L.marker(e.latlng, { draggable: true }).addTo(map);
        marcadorReporte.bindPopup("<b>Ubicación seleccionada para reporte</b>").openPopup();
        
        // Si el usuario arrastra el marcador manualmente, actualizar coordenadas
        marcadorReporte.on('dragend', function(event) {
            let position = marcadorReporte.getLatLng();
            document.getElementById('latitud').value = position.lat.toFixed(6);
            document.getElementById('longitud').value = position.lng.toFixed(6);
        });
    }
});

// 2. GPS: Detectar ubicación del usuario
function detectarGPS() {
    if (!navigator.geolocation) {
        alert("Tu navegador no soporta geolocalización.");
        return;
    }

    navigator.geolocation.getCurrentPosition(function(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;

        map.setView([lat, lng], 16);

        document.getElementById('latitud').value = lat.toFixed(6);
        document.getElementById('longitud').value = lng.toFixed(6);

        if (marcadorReporte) {
            marcadorReporte.setLatLng([lat, lng]);
        } else {
            marcadorReporte = L.marker([lat, lng]).addTo(map);
        }
        marcadorReporte.bindPopup("<b>Te encuentras aquí</b>").openPopup();
    }, function() {
        alert("No se pudo obtener tu ubicación. Por favor selecciona manualmente en el mapa.");
    });
}

// 3. CARGAR MARCADORES DESDE MYSQL (FETCH API)
function cargarReportesExistentes() {
    fetch('get_reports.php')
    .then(response => response.json())
    .then(data => {
        data.forEach(reporte => {
            // Ajustado a tus nuevos valores de prioridad en minúsculas
            let classNameCustom = 'urgencia-media';
            if(reporte.prioridad === 'urgente') classNameCustom = 'urgencia-critica'; // Rojo
            if(reporte.prioridad === 'alta') classNameCustom = 'urgencia-alta';       // Naranja
            if(reporte.prioridad === 'baja') classNameCustom = 'urgencia-baja';       // Verde

            let iconoPersonalizado = L.icon({
                iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
                shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                className: classNameCustom
            });

            const marker = L.marker([reporte.latitud, reporte.longitud], { icon: iconoPersonalizado }).addTo(map);
            
            let popupContent = `
                <div style="max-width: 200px;">
                    <h6 class="text-primary mb-1">${reporte.titulo}</h6>
                    <p class="small mb-1"><b>Tipo:</b> ${reporte.tipo_residuo}<br><b>Prioridad:</b> <span class="badge badge-warning">${reporte.prioridad}</span></p>
                    <p class="small text-muted mb-2">${reporte.descripcion}</p>
                    ${reporte.foto ? `<img src="${reporte.foto}" class="img-fluid rounded mb-1" style="max-height:100px; object-fit:cover;">` : ''}
                    <br><small class="text-muted">${reporte.fecha_reporte}</small>
                </div>
            `;
            marker.bindPopup(popupContent);
        });
    })
    .catch(error => console.error('Error cargando reportes:', error));
}

// 4. GUARDAR REPORTE VÍA AJAX (POST)
document.getElementById('formReporte').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);

    fetch('guardar_reporte.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(res => {
        alert(res);
        this.reset(); // Limpiar formulario
        if (marcadorReporte) map.removeLayer(marcadorReporte); // Quitar marcador temporal
        marcadorReporte = null;
        cargarReportesExistentes(); // Recargar el mapa con el nuevo marcador insertado
    })
    .catch(error => console.error('Error al enviar:', error));
});

// Inicializar cargando los marcadores existentes al abrir la página
document.addEventListener("DOMContentLoaded", cargarReportesExistentes);