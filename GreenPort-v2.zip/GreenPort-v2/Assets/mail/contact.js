$(function () {
    $("#contactForm input, #contactForm textarea").jqBootstrapValidation({
        preventSubmit: true,
        submitError: function ($form, event, errors) {
            // Eventos adicionales en caso de error de validación html
        },
        submitSuccess: function ($form, event) {
            event.preventDefault(); // Detener el envío clásico por recarga
            
            var button = $("#sendMessageButton");
            button.prop("disabled", true).text("Enviando..."); // Efecto visual de espera

            var name = $("input#name").val();
            var email = $("input#email").val();
            var subject = $("input#subject").val();
            var message = $("textarea#message").val();

            $.ajax({
                url: "enviar_contacto.php",
                type: "POST",
                data: {
                    name: name,
                    email: email,
                    subject: subject,
                    message: message
                },
                cache: false,
                success: function () {
                    // Mostrar alerta de éxito
                    $('#success').html("<div class='alert alert-success'>");
                    $('#success > .alert-success').html("<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;")
                        .append("</button>");
                    $('#success > .alert-success')
                        .append("<strong>¡Excelente! Tu mensaje ha sido enviado correctamente a GreenPort. </strong>");
                    $('#success > .alert-success')
                        .append('</div>');
                    
                    // Limpiar el formulario
                    $('#contactForm').trigger("reset");
                },
                error: function () {
                    // Mostrar alerta de falla general
                    $('#success').html("<div class='alert alert-danger'>");
                    $('#success > .alert-danger').html("<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;")
                        .append("</button>");
                    $('#success > .alert-danger').append($("<strong>").text("Lo sentimos, parece que el servidor de correo no está respondiendo en este momento. ¡Inténtalo más tarde!"));
                    $('#success > .alert-danger').append('</div>');
                },
                complete: function () {
                    // Restablecer el botón de envío
                    setTimeout(function () {
                        button.prop("disabled", false).text("Enviar Mensaje");
                    }, 1000);
                }
            });
        },
        filter: function () {
            return $(this).is(":visible");
        },
    });

    $("a[data-toggle=\"tab\"]").click(function (e) {
        e.preventDefault();
        $(this).tab("show");
    });
});

/* Ocultar las cajas de alertas al empezar a escribir de nuevo */
$('#name').focus(function () {
    $('#success').html('');
});