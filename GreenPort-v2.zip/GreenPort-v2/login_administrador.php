<?php
// 1. Iniciar la sesión para mantener al admin conectado
session_start();

// 2. Configuración de la base de datos GreenPort
$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión a la base de datos.");
}

// 3. Validar que los datos vengan por POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Limpiar espacios en blanco
    $email = trim($_POST['usuario']); 
    $password = $_POST['contrasena'];

    if (empty($email) || empty($password)) {
        echo "<script>alert('Por favor, llena todos los campos.'); window.history.back();</script>";
        exit;
    }

    // 4. Consultar al usuario por su email
    $stmt = $conn->prepare("SELECT id, nombre, apellido, password_hash, rol, activo FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificar si el usuario existe
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // 5. Verificar si la cuenta está activa
        if ((bool)$user['activo'] === false) {
            echo "<script>alert('Acceso denegado: Esta cuenta se encuentra inactiva.'); window.history.back();</script>";
            exit;
        }

        // 6. Validar que NO sea un ciudadano común (Filtro de Rol)
        if ($user['rol'] !== 'admin' && $user['rol'] !== 'operador') {
            echo "<script>alert('Acceso restringido: No tienes permisos de administrador.'); window.history.back();</script>";
            exit;
        }

        // 7. Verificar la contraseña encriptada
        if (password_verify($password, $user['password_hash'])) {
            
            // ¡Login correcto! Sincronizamos los nombres de sesión con Panel_Control.php
            $_SESSION['usuario_id']     = $user['id'];
            $_SESSION['usuario_nombre'] = $user['nombre'] . " " . $user['apellido'];
            $_SESSION['usuario_rol']    = $user['rol'];
            
            // Redirigir al Panel de Control de administradores
            header("Location: Panel_Control.php");
            exit;

        } else {
            // Contraseña incorrecta
            echo "<script>alert('Contraseña incorrecta. Inténtalo de nuevo.'); window.history.back();</script>";
        }
    } else {
        // Correo no registrado
        echo "<script>alert('El usuario no existe o no está registrado.'); window.history.back();</script>";
    }

    $stmt->close();
}
$conn->close();
?>