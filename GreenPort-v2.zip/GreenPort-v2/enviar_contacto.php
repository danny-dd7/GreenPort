<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluir el archivo de configuración externa
require_once 'config.php';

// Cargar archivos de PHPMailer (Ajusta la ruta según tu estructura)
require 'Assets/PHPMailer/Exception.php';
require 'Assets/PHPMailer/PHPMailer.php';
require 'Assets/PHPMailer/SMTP.php';

// Validar que la solicitud sea POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Sanitizar y recibir los datos del formulario
    $nombre    = strip_tags(trim($_POST["name"]));
    $email     = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $asunto    = strip_tags(trim($_POST["subject"]));
    $mensaje   = trim($_POST["message"]);

    // Validar campos obligatorios
    if (empty($nombre) || empty($asunto) || empty($mensaje) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo "Por favor, completa todos los campos correctamente.";
        exit;
    }

    $mail = new PHPMailer(true);

    try {
        // Configuración del Servidor SMTP de Gmail
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
         // USAR LAS CONSTANTES DEL ARCHIVO CONFIG
        $mail->Username   = SMTP_USER;          
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        // Destinatarios y Remitente
        // Nota: Gmail sobreescribe el 'From' por seguridad con tu cuenta de Username,
        // pero añadimos el ReplyTo para que cuando le des "Responder", le responda directo al ciudadano.
        $mail->setFrom('greenportmxt@gmail.com', 'GreenPort Sistema');
        $mail->addAddress('greenportmxt@gmail.com');            // Correo que recibirá la notificación
        $mail->addReplyTo($email, $nombre);                     // El correo del ciudadano que escribe

        // Contenido del Correo Electrónico (Diseño HTML limpio)
        $mail->isHTML(true);
        $mail->Subject = "Contacto GreenPort: " . $asunto;
        
        $bodyContent = "
        <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 8px; max-width: 600px;'>
            <h2 style='color: #7AB730;'>Nuevo Mensaje de Contacto - GreenPort</h2>
            <hr style='border: 0; border-top: 1px solid #eee;'>
            <p><strong>Nombre del Ciudadano:</strong> {$nombre}</p>
            <p><strong>Correo Electrónico:</strong> <a href='mailto:{$email}'>{$email}</a></p>
            <p><strong>Asunto:</strong> {$asunto}</p>
            <div style='background-color: #f9f9f9; padding: 15px; border-left: 4px solid #7AB730; margin-top: 15px;'>
                <p style='margin: 0; font-style: italic;'>\"{$mensaje}\"</p>
            </div>
            <hr style='border: 0; border-top: 1px solid #eee; margin-top: 20px;'>
            <p style='font-size: 11px; color: #888;'>Este correo fue generado automáticamente desde el formulario de contacto del sitio web GreenPort Acapulco.</p>
        </div>";
        
        $mail->Body = $bodyContent;

        // Enviar Correo
        $mail->send();
        http_response_code(200);
        echo "¡Tu mensaje ha sido enviado con éxito!";
    } catch (Exception $e) {
        http_response_code(500);
        echo "Hubo un error al enviar el mensaje. Error de entrega.";
    }

} else {
    http_response_code(403);
    echo "Hubo un problema con tu envío, por favor intenta de nuevo.";
}
?>