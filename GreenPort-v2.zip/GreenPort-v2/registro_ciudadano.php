<?php
// 1. Conexión a la base de datos GreenPort
$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);

// Validar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// 2. Procesar los datos solo si vienen por POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    // Recolectar y limpiar los datos del formulario HTML
    $nombre   = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email    = trim($_POST['correo']);
    $telefono = trim($_POST['telefono']);
    $password = $_POST['password'];

    // Validación básica de campos obligatorios vacíos
    if (empty($nombre) || empty($apellido) || empty($email) || empty($password)) {
        echo "<script>
                alert('Por favor, completa todos los campos obligatorios.');
                window.history.back();
              </script>";
        exit;
    }

    // 3. Verificar si el correo ya está registrado para evitar duplicados
    $verificarEmail = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $verificarEmail->bind_param("s", $email);
    $verificarEmail->execute();
    $resultado = $verificarEmail->get_result();

    if ($resultado->num_rows > 0) {
        echo "<script>
                alert('Este correo electrónico ya está registrado. Intenta con otro o inicia sesión.');
                window.history.back();
              </script>";
        $verificarEmail->close();
        exit;
    }
    $verificarEmail->close();

    // 4. Encriptar la contraseña de forma segura (Hash)
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // 5. Insertar al nuevo ciudadano en la base de datos
    // Por defecto, el rol será 'ciudadano' y estará 'activo' según tu estructura
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, email, password_hash, telefono, rol, activo) VALUES (?, ?, ?, ?, ?, 'ciudadano', 1)");
    $stmt->bind_param("sssss", $nombre, $apellido, $email, $password_hash, $telefono);

    if ($stmt->execute()) {
        // ¡ÉXITO! Aquí está la alerta pequeña que querías y la redirección automática
        echo "<script>
                alert('¡Usuario registrado correctamente!');
                window.location.href = 'login.html';
              </script>";
    } else {
        // En caso de que ocurra un error interno de MySQL
        echo "<script>
                alert('Hubo un error al registrar tu cuenta. Por favor, inténtalo de nuevo.');
                window.history.back();
              </script>";
    }

    $stmt->close();
}

$conn->close();
?>