<?php
// Configuración de la base de datos real GreenPort
$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error crítico de conexión al servidor.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recoger y limpiar los datos para evitar inyecciones básicas o espacios extra
    $nombre   = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email    = trim($_POST['email']);
    $telefono = trim($_POST['telefono']);
    $password = $_POST['contrasena'];
    
    // Forzamos el rol exclusivo de administrador
    $rol = 'admin'; 
    $activo = 1;

    // Validación elemental en backend
    if (empty($nombre) || empty($apellido) || empty($email) || empty($password)) {
        echo "<script>alert('Error: Todos los campos obligatorios deben ser completados.'); window.history.back();</script>";
        exit;
    }

    // 1. Verificar si el correo electrónico ya se encuentra registrado
    $checkEmail = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if ($checkEmail->num_rows > 0) {
        echo "<script>alert('El correo electrónico ya está registrado en el sistema GreenPort.'); window.history.back();</script>";
        $checkEmail->close();
        $conn->close();
        exit;
    }
    $checkEmail->close();

    // 2. ENCRIPTACIÓN DE CONTRASEÑA (Seguridad Obligatoria)
    // Usamos PASSWORD_BCRYPT para generar la cadena segura que se guardará en password_hash
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // 3. Insertar el nuevo administrador en la tabla 'usuarios'
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, email, password_hash, telefono, rol, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $nombre, $apellido, $email, $password_hash, $telefono, $rol, $activo);

    if ($stmt->execute()) {
        // Registro exitoso, redirigimos a la pantalla de Login con alerta limpia
        echo "<script>
                alert('Administrador dado de alta de manera exitosa en GreenPort.');
                window.location.href = 'Administrador.html'; 
              </script>";
    } else {
        echo "<script>alert('Error inesperado al guardar el registro en la base de datos.'); window.history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>