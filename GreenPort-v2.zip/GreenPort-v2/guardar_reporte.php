<?php
$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort"; // Nombre real de tu Base de Datos

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario_id = intval($_POST['usuario_id']); 
    $titulo = trim($_POST['titulo']);
    $descripcion = trim($_POST['descripcion']);
    $tipo_residuo = trim($_POST['tipo_residuo']);
    $prioridad = trim($_POST['prioridad']); // Cambió de urgencia -> prioridad
    $latitud = floatval($_POST['latitud']);
    $longitud = floatval($_POST['longitud']);
    $estado = "pendiente"; // Por defecto según tu ENUM

    if (empty($titulo) || empty($latitud) || empty($longitud)) {
        echo "Por favor, completa los datos de ubicación en el mapa.";
        exit;
    }

    // Insertar reporte en la base de datos estructurada por ti
    $stmt = $conn->prepare("INSERT INTO reportes (usuario_id, titulo, descripcion, tipo_residuo, prioridad, latitud, longitud, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssdds", $usuario_id, $titulo, $descripcion, $tipo_residuo, $prioridad, $latitud, $longitud, $estado);
    
    if ($stmt->execute()) {
        $reporte_id = $conn->insert_id;

        // Procesar archivo fotográfico
        if (!empty($_FILES['foto']['name'])) {
            // 1. Definimos la carpeta destino CORRECTA dentro de tu proyecto
            $uploadDir = 'Assets/img/reportes/';
            
            // Si por alguna razón no existe la carpeta, PHP la crea automáticamente
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // 2. Extraemos la extensión del archivo (jpg, png, etc.)
            $fileName = basename($_FILES['foto']['name']);
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            
            // 3. Creamos un nombre ÚNICO y limpio (Ej: evidencia_647a8b9c.jpg)
            $newFileName = "evidencia_" . uniqid() . "." . $fileExtension;
            
            // 4. Ruta completa donde se moverá el archivo temporal en el servidor
            $targetFilePath = $uploadDir . $newFileName;

            // Validar que realmente sea una imagen permitida
            if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])) {
                // Mover el archivo de la memoria temporal a la carpeta del proyecto
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $targetFilePath)) {
                    
                    $tipo_archivo = $_FILES['foto']['type'];
                    
                    // IMPORTANTE: En 'url_archivo' guardamos SOLO el nombre ($newFileName), no toda la ruta.
                    // Así el Muro Comunitario puede jalarlo fácilmente con Assets/img/reportes/<?php echo $foto; ? >
                    $stmtFoto = $conn->prepare("INSERT INTO evidencias (reporte_id, url_archivo, tipo_archivo) VALUES (?, ?, ?)");
                    $stmtFoto->bind_param("iss", $reporte_id, $newFileName, $tipo_archivo);
                    $stmtFoto->execute();
                    $stmtFoto->close();
                }
            }
        }
        
        // Alerta estética y redirección inmediata al Muro Comunitario recién hecho
        echo "<script>
                alert('¡Reporte ciudadano guardado con éxito en GreenPort Acapulco!');
                window.location.href = 'principal_ciudadano.php';
              </script>";
              
    } else {
        echo "<script>
                alert('Error al guardar el reporte: " . $conn->error . "');
                window.history.back();
              </script>";
    }
    $stmt->close();
}
$conn->close();
?>