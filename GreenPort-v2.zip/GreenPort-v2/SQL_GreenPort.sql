CREATE DATABASE GreenPort;
USE GreenPort;

-- TABLA USUARIOS 
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    rol ENUM('ciudadano','operador','admin') DEFAULT 'ciudadano',
    activo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TABLA REPORTES
CREATE TABLE reportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT NOT NULL,
    tipo_residuo ENUM(
        'Residuos Sólidos Urbanos',
        'Plásticos y Botellas',
        'Materiales Tóxicos',
        'Escombros',
        'Desechos Orgánicos',
        'Otros'
    ) NOT NULL,
    estado ENUM(
        'pendiente',
        'en_revision',
        'en_proceso',
        'resuelto',
        'rechazado'
    ) DEFAULT 'pendiente',
    prioridad ENUM(
        'baja',
        'media',
        'alta',
        'urgente'
    ) DEFAULT 'media',
    zona VARCHAR(255),
    direccion TEXT,
    latitud DECIMAL(10,8) NOT NULL,
    longitud DECIMAL(11,8) NOT NULL,
    fecha_reporte TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id)
    ON DELETE CASCADE
);

-- TABLA EVIDENCIAS 
CREATE TABLE evidencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporte_id INT NOT NULL,
    url_archivo VARCHAR(500) NOT NULL,
    tipo_archivo VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (reporte_id)
    REFERENCES reportes(id)
    ON DELETE CASCADE
);

-- TABLA SEGUIMIENTOS
CREATE TABLE seguimiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporte_id INT NOT NULL,
    operador_id INT,
    estado ENUM(
        'pendiente',
        'en_revision',
        'en_proceso',
        'resuelto',
        'rechazado'
    ) NOT NULL,
    comentario TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (reporte_id)
    REFERENCES reportes(id)
    ON DELETE CASCADE,

    FOREIGN KEY (operador_id)
    REFERENCES usuarios(id)
    ON DELETE SET NULL
);

-- TABLA ASIGNACIONES
CREATE TABLE asignaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporte_id INT NOT NULL,
    operador_id INT NOT NULL,
    notas TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (reporte_id)
    REFERENCES reportes(id)
    ON DELETE CASCADE,

    FOREIGN KEY (operador_id)
    REFERENCES usuarios(id)
    ON DELETE CASCADE
);

-- TABLA NOTIFICACIONES
CREATE TABLE notificaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    reporte_id INT,
    titulo VARCHAR(255),
    mensaje TEXT NOT NULL,
    leido BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id)
    ON DELETE CASCADE,

    FOREIGN KEY (reporte_id)
    REFERENCES reportes(id)
    ON DELETE CASCADE
);

-- Tabla para los locales comunitarios registrados por usuarios
CREATE TABLE locales_comunitarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT NOT NULL,
    categoria ENUM('Restaurantes', 'Cafeterías', 'Artesanías', 'Playas', 'Turismo', 'Hospedaje local', 'Eventos', 'Cultura', 'Vida nocturna') NOT NULL,
    latitud DECIMAL(10, 8) NOT NULL,
    longitud DECIMAL(11, 8) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    horario VARCHAR(100),
    telefono VARCHAR(20),
    redes_sociales VARCHAR(255),
    foto_url VARCHAR(255) DEFAULT 'default_local.png',
    estado ENUM('pendiente', 'aprobado', 'rechazado') DEFAULT 'pendiente',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabla para las calificaciones y comentarios de los locales
CREATE TABLE valoraciones_locales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_id INT NOT NULL,
    usuario_id INT NOT NULL,
    estrellas INT CHECK (estrellas >= 1 AND estrellas <= 5),
    comentario TEXT,
    fecha_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (local_id) REFERENCES locales_comunitarios(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS comentarios_locales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_id INT NOT NULL,
    usuario_id INT NOT NULL,
    estrellas INT NOT NULL CHECK (estrellas >= 1 AND estrellas <= 5),
    comentario TEXT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (local_id) REFERENCES locales_comunitarios(id) ON DELETE CASCADE
);

show tables;
select * from usuarios;
select * from reportes;
-- select * from asignaciones;
select * from evidencias;
-- select * from notificaciones;
select * from seguimiento;
select * from comentarios_locales;
select * from locales_comunitarios;
select * from valoraciones_locales;

DROP TABLE IF EXISTS asignaciones;
DROP TABLE IF EXISTS notificaciones;