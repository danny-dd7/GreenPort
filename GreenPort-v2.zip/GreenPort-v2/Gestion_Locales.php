<?php
session_start();
// Verificar si el administrador ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.html");
    exit();
}

// Conexión a la Base de Datos
$conn = new mysqli("localhost", "root", "cazadorx", "GreenPort");

// --- PROCESAR ACCIONES DEL ADMINISTRADOR ---

// 1. Aprobar o Rechazar el local
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar_estado_local'])) {
    $local_id = $_POST['local_id'];
    $nuevo_estado = $_POST['nuevo_estado'];

    $stmt = $conn->prepare("UPDATE locales_comunitarios SET estado = ? WHERE id = ?");
    $stmt->bind_param("si", $nuevo_estado, $local_id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Estado del local actualizado con éxito.'); window.location.href='Gestion_Locales.php';</script>";
    }
    $stmt->close();
}

// 2. Eliminar definitivamente el local
if (isset($_GET['eliminar_local'])) {
    $local_id = $_GET['eliminar_local'];

    $stmt = $conn->prepare("DELETE FROM locales_comunitarios WHERE id = ?");
    $stmt->bind_param("i", $local_id);
    
    if ($stmt->execute()) {
        echo "<script>alert('El local ha sido eliminado permanentemente.'); window.location.href='Gestion_Locales.php';</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>GreenPort - Panel Administración Locales</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="Assets/img/logo.png" rel="icon" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="Assets/css/style.css" rel="stylesheet">
    <style>
        body { background-color: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; }
        .sidebar { min-width: 250px; max-width: 250px; background: #2c3e50; min-height: 100vh; transition: all 0.3s; }
        .sidebar .nav-link { color: #8a99a7; font-size: 14px; border-bottom: 1px solid #34495e; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: #1abc9c; color: white !important; }
        .content-area { width: 100%; padding: 30px; }
        .card-custom { border-radius: 15px; border: none; }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar">
        <div class="p-4 text-center border-bottom border-secondary">
            <h3 class="text-white font-weight-bold m-0"><span style="color: #1abc9c;">GREEN</span>PORT</h3>
            <small class="text-muted d-block mt-1">Operador: <?php echo htmlspecialchars($_SESSION['usuario_nombre'] ?? 'Admin'); ?></small>
        </div>
        <div class="pt-3">
            <a href="Panel_Control.php" class="nav-link text-white py-3 px-4 d-block">
                <i class="fas fa-tachometer-alt mr-2"></i> Dashboard / Reportes
            </a>
            <a href="Gestion_Locales.php" class="nav-link active text-white py-3 px-4 d-block">
                <i class="fas fa-store mr-2"></i> Gestión Locales
            </a>
            <a href="#" class="nav-link text-white py-3 px-4 d-block">
                <i class="fas fa-comments mr-2"></i> Ver Foro Comunitario
            </a>
            <hr class="border-secondary my-4">
            <a href="cerrar_sesion.php" class="nav-link text-danger py-3 px-4 d-block">
                <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
            </a>
        </div>
    </nav>

    <div class="content-area">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="font-weight-bold text-dark m-0">Panel de Administración Integral</h2>
            <span class="badge badge-dark p-2"><i class="fas fa-user-shield mr-1"></i> Rol: Admin</span>
        </div>

        <div class="card card-custom p-4 bg-white shadow-sm">
            <div class="d-flex align-items-center mb-3">
                <i class="fas fa-store-alt fa-2x text-info mr-3"></i>
                <div>
                    <h4 class="font-weight-bold m-0" style="color: #333;">Control Operativo de Negocios Locales</h4>
                    <p class="text-muted small m-0">Modera las solicitudes de comercios de Acapulco. Prioriza el consumo local sobre grandes cadenas.</p>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle" style="font-size: 13px;">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Imagen</th>
                            <th>Negocio / Lugar</th>
                            <th>Categoría</th>
                            <th>Ubicación / Dirección</th>
                            <th>Contacto / Redes</th>
                            <th>Estado Operativo</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Consultar todos los locales registrados en la base de datos
                        $query = "SELECT l.*, u.nombre AS ciudadano_nombre 
                                  FROM locales_comunitarios l 
                                  LEFT JOIN usuarios u ON l.usuario_id = u.id 
                                  ORDER BY l.fecha_registro DESC";
                        $resultado = $conn->query($query);

                        if ($resultado && $resultado->num_rows > 0):
                            while ($local = $resultado->fetch_assoc()):
                                // Color del badge según el estado operativo
                                $badge_class = 'badge-warning'; // pendiente
                                if ($local['estado'] == 'aprobado') $badge_class = 'badge-success';
                                if ($local['estado'] == 'rechazado') $badge_class = 'badge-danger';
                        ?>
                        <tr>
                            <td><b>#<?php echo $local['id']; ?></b></td>
                            <td>
                                <img src="Assets/img/locales/<?php echo $local['foto_url']; ?>" 
                                     style="width: 55px; height: 45px; object-fit: cover; border-radius: 5px;"
                                     onerror="this.src='Assets/img/logo.png'">
                            </td>
                            <td>
                                <span class="font-weight-bold text-dark d-block"><?php echo htmlspecialchars($local['nombre']); ?></span>
                                <small class="text-muted">Por: <?php echo htmlspecialchars($local['ciudadano_nombre'] ?? 'Desconocido'); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-light border px-2 py-1"><?php echo $local['categoria']; ?></span>
                            </td>
                            <td>
                                <span class="text-truncate d-block" style="max-width: 180px;" title="<?php echo htmlspecialchars($local['direccion']); ?>">
                                    📍 <?php echo htmlspecialchars($local['direccion']); ?>
                                </span>
                                <small class="text-info font-weight-bold">Coords: <?php echo $local['latitud']; ?>, <?php echo $local['longitud']; ?></small>
                            </td>
                            <td>
                                <small class="d-block">📞 <?php echo htmlspecialchars($local['telefono'] ?: 'S/N'); ?></small>
                                <?php if ($local['redes_sociales']): ?>
                                    <a href="<?php echo htmlspecialchars($local['redes_sociales']); ?>" target="_blank" class="badge badge-info text-white"><i class="fab fa-link"></i> Ver Redes</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $badge_class; ?> text-uppercase p-2 d-block text-center text-white font-weight-bold">
                                    <?php echo $local['estado']; ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <div class="d-flex justify-content-center align-items-center">
                                    <form action="Gestion_Locales.php" method="POST" class="form-inline mr-2">
                                        <input type="hidden" name="local_id" value="<?php echo $local['id']; ?>">
                                        <select name="nuevo_estado" class="form-control form-control-sm mr-1" onchange="this.form.submit()" style="font-size: 11px; height: auto;">
                                            <option value="" disabled selected>Moderar...</option>
                                            <option value="pendiente" <?php if($local['estado']=='pendiente') echo 'disabled'; ?>>Pendiente</option>
                                            <option value="aprobado" <?php if($local['estado']=='aprobado') echo 'disabled'; ?>>Aprobar</option>
                                            <option value="rechazado" <?php if($local['estado']=='rechazado') echo 'disabled'; ?>>Rechazar</option>
                                        </select>
                                        <input type="hidden" name="actualizar_estado_local" value="1">
                                    </form>

                                    <a href="Gestion_Locales.php?eliminar_local=<?php echo $local['id']; ?>" 
                                       class="btn btn-sm btn-outline-danger" 
                                       onclick="return confirm('¿Seguro que deseas eliminar permanentemente este local comercial?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php 
                            endwhile; 
                        else:
                        ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">No hay propuestas de locales registrados en la plataforma.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
</body>
</html>