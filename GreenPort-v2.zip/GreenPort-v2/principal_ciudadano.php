<?php
// 1. Iniciar sesión y validar seguridad
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.html");
    exit;
}

// 2. Conexión a tu MySQL Workbench
$servername = "localhost";
$username = "root";
$password = "cazadorx";
$dbname = "GreenPort";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// ==========================================
// PROCESAR NUEVO COMENTARIO (FORO)
// ==========================================
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'comentar') {
    $reporte_id = intval($_POST['reporte_id']);
    $usuario_id = $_SESSION['usuario_id'];
    $comentario = trim($_POST['comentario']);
    $estado_actual = $_POST['estado_reporte'];

    if (!empty($comentario)) {
        $stmt_com = $conn->prepare("INSERT INTO seguimiento (reporte_id, operador_id, estado, comentario) VALUES (?, ?, ?, ?)");
        $stmt_com->bind_param("iiss", $reporte_id, $usuario_id, $estado_actual, $comentario);
        $stmt_com->execute();
        $stmt_com->close();
        echo "<script>window.location.href='principal_ciudadano.php';</script>";
        exit;
    }
}

// ==========================================
// OBTENER PINES PARA EL MAPA PANORÁMICO
// ==========================================
$query_mapa = "SELECT id, titulo, estado, latitud, longitud FROM reportes";
$res_mapa = $conn->query($query_mapa);
$pines_mapa = [];
while($m = $res_mapa->fetch_assoc()) {
    $pines_mapa[] = $m;
}
$pines_json = json_encode($pines_mapa);

// ==========================================
// OBTENER REPORTES CON SUS EVIDENCIAS (FOTOS)
// ==========================================
// Relación estricta con LEFT JOIN para jalar el nombre de la foto guardada
$query_muro = "SELECT r.*, u.nombre, u.apellido, e.url_archivo 
               FROM reportes r 
               INNER JOIN usuarios u ON r.usuario_id = u.id 
               LEFT JOIN evidencias e ON r.id = e.reporte_id
               ORDER BY r.fecha_reporte DESC";
$resultado_muro = $conn->query($query_muro);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Inicio | GreenPort Comunidad</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="Assets/img/Logo.png" rel="icon" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="Assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; }
        .navbar-green { background-color: #343a40; border-bottom: 3px solid #7AB730; }
        #mapa-panoramico { height: 380px; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .card-reporte { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 30px; overflow: hidden; }
        
        /* Contenedor adaptativo para que las imágenes mantengan proporción estética */
        .contenedor-img { width: 100%; max-height: 400px; overflow: hidden; background-color: #eaeaea; display: flex; align-items: center; justify-content: center; }
        .img-reporte { width: 100%; height: 100%; object-fit: cover; }
        
        .btn-reportar { background-color: #7AB730; color: white; font-weight: 600; border-radius: 30px; transition: 0.3s; }
        .btn-reportar:hover { background-color: #639624; color: white; box-shadow: 0 4px 10px rgba(122,183,48,0.4); }
        .box-comentarios { background-color: #f8f9fa; border-radius: 10px; padding: 15px; max-height: 220px; overflow-y: auto; border: 1px solid #eef0f2; }
        .badge-categoria { background-color: #e9ecef; color: #495057; font-weight: 500; }
        .badge-pendiente { background-color: #ffc107; color: #212529; }
        .badge-proceso { background-color: #007bff; color: white; }
        .badge-resuelto { background-color: #28a745; color: white; }
        .badge-rechazado { background-color: #dc3545; color: white; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-green sticky-top p-3 shadow-sm">
        <a class="navbar-brand font-weight-bold text-white" href="#">GREEN<span style="color: #7AB730;">PORT</span></a>
        <div class="ml-auto d-flex align-items-center">
            <span class="text-white-50 mr-3">Ciudadano: <strong class="text-white"><?php echo $_SESSION['usuario_nombre']; ?></strong></span>
            <a href="logout.php" class="btn btn-sm btn-outline-danger"><i class="fas fa-sign-out-alt"></i> Salir</a>
        </div>
    </nav>

    <div class="container py-4">
        
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 p-3 bg-white rounded-15 shadow-sm">
                    <h5 class="font-weight-bold mb-3 text-dark"><i class="fas fa-map-marked-alt text-success mr-2"></i> Vista Panorámica de Incidentes (Acapulco)</h5>
                    <div id="mapa-panoramico"></div>
                </div>
            </div>
        </div>

        <div class="row">
            
            <div class="col-lg-8">
                <h4 class="font-weight-bold mb-4 text-dark"><i class="fas fa-stream text-success mr-2"></i> Reportes Recientes de la Comunidad</h4>
                
                <?php if ($resultado_muro->num_rows > 0): ?>
                    <?php while($reporte = $resultado_muro->fetch_assoc()): ?>
                        <div class="card card-reporte bg-white">
                            
                            <div class="contenedor-img">
                                <?php if (!empty($reporte['url_archivo'])): ?>
                                    <img src="Assets/img/reportes/<?php echo htmlspecialchars($reporte['url_archivo']); ?>" class="img-reporte" alt="Evidencia de Acumulación de Basura">
                                <?php else: ?>
                                    <div class="text-center py-5 text-muted w-100 bg-light">
                                        <i class="fas fa-recycle fa-4x text-muted mb-2"></i>
                                        <br><span class="small font-italic">Este reporte fue compartido sin fotografía de evidencia inicial.</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h4 class="card-title font-weight-bold text-dark m-0"><?php echo htmlspecialchars($reporte['titulo']); ?></h4>
                                    <?php 
                                        $estado = $reporte['estado'];
                                        $clase_badge = "badge-pendiente";
                                        if($estado === 'en_proceso' || $estado === 'en_revision') $clase_badge = "badge-proceso";
                                        if($estado === 'resuelto') $clase_badge = "badge-resuelto";
                                        if($estado === 'rechazado') $clase_badge = "badge-rechazado";
                                    ?>
                                    <span class="badge <?php echo $clase_badge; ?> px-3 py-2 text-capitalize"><?php echo str_replace('_', ' ', $estado); ?></span>
                                </div>
                                
                                <p class="text-muted small mb-3">
                                    <i class="fas fa-user-circle mr-1"></i> Publicado por: <strong><?php echo htmlspecialchars($reporte['nombre'] . " " . $reporte['apellido']); ?></strong> | 
                                    <i class="fas fa-clock mx-1"></i> <?php echo date("d/m/Y g:i a", strtotime($reporte['fecha_reporte'])); ?>
                                </p>
                                
                                <div class="mb-3">
                                    <span class="badge badge-categoria p-2 mr-2">
                                        <i class="fas fa-dumpster text-success mr-1"></i> <?php echo htmlspecialchars($reporte['tipo_residuo']); ?>
                                    </span>
                                    <span class="badge badge-light p-2">
                                        <i class="fas fa-map-marker-alt text-danger mr-1"></i> 
                                        Ubicación: <strong>
                                        <?php 
                                            // Si tiene una zona escrita la pone, si no, pone las coordenadas reales del mapa
                                            if (!empty($reporte['zona'])) {
                                                echo htmlspecialchars($reporte['zona']);
                                            } else {
                                                echo "Lat: " . number_format($reporte['latitud'], 4) . " | Lon: " . number_format($reporte['longitud'], 4);
                                            }
                                        ?>
                                        </strong>
                                    </span>
                                </div>

                                <p class="card-text bg-light p-3 rounded font-weight-normal" style="border-left: 4px solid #7AB730; color: #212529 !important; font-size: 15px;">
                                    <?php echo htmlspecialchars($reporte['descripcion']); ?>
                                </p>
                             <hr>

                                <h6 class="font-weight-bold text-dark mb-2"><i class="fas fa-comments text-muted mr-1"></i> Conversación Ciudadana:</h6>
                                <div class="box-comentarios mb-3">
                                    <?php 
                                    $rep_id = $reporte['id'];
                                    $query_comentarios = "SELECT s.comentario, s.created_at, u.nombre, u.apellido, u.rol 
                                                          FROM seguimiento s 
                                                          INNER JOIN usuarios u ON s.operador_id = u.id 
                                                          WHERE s.reporte_id = $rep_id 
                                                          ORDER BY s.created_at ASC";
                                    $res_comentarios = $conn->query($query_comentarios);
                                    
                                    if($res_comentarios->num_rows > 0): 
                                        while($com = $res_comentarios->fetch_assoc()):
                                            $clase_nombre = ($com['rol'] !== 'ciudadano') ? 'text-danger' : 'text-primary';
                                            $tag_rol = ($com['rol'] !== 'ciudadano') ? ' <span class="badge badge-danger text-capitalize" style="font-size:9px;">'.$com['rol'].'</span>' : '';
                                    ?>
                                            <div class="border-bottom pb-2 mb-2">
                                                <p class="m-0 small">
                                                    <strong class="<?php echo $clase_nombre; ?>"><?php echo htmlspecialchars($com['nombre'] . " " . $com['apellido']) . $tag_rol; ?></strong> 
                                                    <span class="text-muted float-right" style="font-size: 10px;"><i class="far fa-clock mr-1"></i><?php echo date("d/m H:i", strtotime($com['created_at'])); ?></span>
                                                </p>
                                                <p class="m-0 text-dark mt-1" style="font-size: 13px; font-weight: 400;"><?php echo htmlspecialchars($com['comentario']); ?></p>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <p class="text-muted small m-0 text-center py-3 font-italic">No hay comentarios en este reporte comunitario todavía.</p>
                                    <?php endif; ?>
                                </div>

                                <form action="principal_ciudadano.php" method="POST">
                                    <input type="hidden" name="action" value="comentar">
                                    <input type="hidden" name="reporte_id" value="<?php echo $reporte['id']; ?>">
                                    <input type="hidden" name="estado_reporte" value="<?php echo $reporte['estado']; ?>">
                                    <div class="input-group">
                                        <input type="text" name="comentario" class="form-control form-control-sm" placeholder="Escribe un mensaje constructivo o actualización del problema..." required>
                                        <div class="input-group-append">
                                            <button class="btn btn-sm btn-success px-4" type="submit"><i class="fas fa-paper-plane mr-1"></i> Enviar</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="alert alert-light text-center shadow-sm py-4">No se han registrado incidencias en el sistema de GreenPort para esta región.</div>
                <?php endif; ?>
            </div>

            <div class="col-lg-4 sticky-top" style="top: 100px; z-index: 5; height: max-content;">
    
                <div class="card border-0 p-4 bg-white rounded-15 shadow-sm text-center">
                    <div class="p-3 bg-light rounded-circle d-inline-block mb-3">
                        <i class="fas fa-dumpster fa-2x text-success"></i>
                    </div>
                    <h5 class="font-weight-bold text-dark">¿Encontraste un foco de contaminación?</h5>
                    <p class="text-muted small mb-4">Levanta una alerta de inmediato. Tu reporte será geolocalizado en el mapa panorámico municipal para la asignación de cuadrillas.</p>
                    <a href="reportar.html" class="btn btn-reportar btn-block py-2 shadow-sm">
                        <i class="fas fa-plus-circle mr-2"></i> Crear Nuevo Reporte
                    </a>
                </div>

                <div class="card card-custom p-4 bg-white mt-4 text-center shadow-sm" style="border-radius: 15px;">
                    <div class="mb-3">
                        <i class="fas fa-store-alt fa-3x text-info"></i>
                    </div>
                    <h4 class="font-weight-bold text-dark" style="font-size: 1.3rem;">¿Tienes un negocio o lugar favorito?</h4>
                    <p class="text-muted small px-2">
                        Ayuda a los turistas y ciudadanos a descubrir rincones únicos de Acapulco. Registra restaurantes, artesanías o playas recomendadas.
                    </p>
                    <a href="registrar_local.php" class="btn btn-info btn-block py-2 font-weight-bold text-white shadow-sm" style="border-radius: 25px; background-color: #17a2b8; border: none;">
                        <i class="fas fa-plus-circle mr-2"></i>Registrar Negocio Local
                    </a>
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        var mapa = L.map('mapa-panoramico').setView([16.8531, -99.8749], 12);

        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap &copy; CARTO',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(mapa);

        var reportesDB = <?php echo $pines_json; ?>;
        reportesDB.forEach(function(rep) {
            if(rep.latitud && rep.longitud) {
                L.marker([parseFloat(rep.latitud), parseFloat(rep.longitud)]).addTo(mapa)
                    .bindPopup('<b>' + rep.titulo + '</b><br>Estado: ' + rep.estado);
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>